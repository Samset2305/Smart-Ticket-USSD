<?php

use AfricasTalking\SDK\AfricasTalking;
require 'vendor/autoload.php';

//Ensures this code runs only after a POST from AT

//remeber to return to if(!empty($_POST))
if(empty(!$_POST)) {

require_once('config.php'); // AT configuration file
require_once('dbConnector.php'); //Connects to database
require_once('AfricasTalking.php'); //AT Gateway
require_once('Service.php');
require_once('Response.php'); //File containing all resposes to user
require_once('Payments.php'); //AT Payments
require_once('SMS.php'); //AT Sms
require_once('functions.php'); // App Functions

 
ini_set('error_log', 'ATussd-app-error.log');



// Reads the variables sent via POST from AT gateway


$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"];  
 

 
// Initialize the SDK
$AT = new AfricasTalking($username, $apiKey);



//Explode the text to get the value of the latest interaction - think 1*1
$textArray = explode('*', $text);
$userResponse = trim(end($textArray));

//Set the default level of the user
$menuNumber = 0;

//Check the level of the user from the DB and retain default level if none is found for this session
$sql = "SELECT menuNumber FROM session_levels WHERE sessionId ='".$sessionId."' LIMIT 1";
$menuNumberQuery = $db->query($sql);
if ($menuNumberQueryResult = $menuNumberQuery->fetch_assoc()) {
    $menuNumber = $menuNumberQueryResult['menuNumber'];
}


//Check if the user is registered in the database
$sql7 = "SELECT * FROM account WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1";
$userQuery = $db->query($sql7);
$userAvailable = $userQuery->fetch_assoc();

//Check if the user is available (no)->Register the user
if (!$userAvailable) {
    
	
	 $sq99 = "INSERT INTO account (phoneNumber) VALUES('".$phoneNumber."')";
     $db->query($sq99);
	
}


// Serve the Services Menu


if ($menuNumber == 0 || $menuNumber == 1) {
        switch ($userResponse) {
			
// Main Menu
            case "":
                if ($menuNumber == 0 ||$menuNumber == 1) {
                    
                 
                    //9b. Graduate user to next level & Serve Main Menu
                    $sql9b = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 1 )";
                    $db->query($sql9b);
					$sql9c = "INSERT INTO `ussdTransactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                    //Serve our services menu

                    $response= "CON Welcome to Mr. Taxi\n";
                    $response.= "1. Lagos\n";
                    $response.= "2.. Lagos";
                    
                    echo $response;
                }
                break;
            case "0":
                if ($menuNumber == 1) {

                    $sql00 = "INSERT INTO session_levels`(`sessionId`,`phonenumber`,`menuNumber`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                    $db->query($sql00);
					$sql9c = "INSERT INTO `ussdTransactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                   
                   $response= "CON Welcome to Mr. Taxi\n";
                    $response.= "1. Lagos\n";
                    $response.= "2.. Lagos";
                    
                    echo $response;
                }
                break;
            case "1":
                if ($menuNumber == 1) {

                    $sql01 = "UPDATE session_levels SET  menuNumber=10 WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01);
					$sql01a = "UPDATE ussdTransactions SET  state = 'Lagos' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
					
                   $response= "CON Enter your location address:\n";
                    
                    
                    echo $response;
                }
                break;
            case "2":
                if ($menuNumber == 1) {

                    $sql02 = "UPDATE session_levels SET menuNumber =20 WHERE sessionId = '".$sessionId."'";
                    $db->query($sql02);
					
					$sql01a = "UPDATE ussdTransactions SET  state = 'Abuja' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
                  
                    $response= "CON Enter your location address:\n";
                    
                    
                    echo $response;

            
                }
                break;
	


	
				
        }
    }else {
        switch ($menuNumber) {
            
				 case "10":
				     
				     $locationAddress= $userResponse;
                        
							//Save Location  address and Request Destionation Address
							
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET locationAddress='".$locationAddress."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
					$response= "CON Enter your destination address";
                    
                    echo $response;
                    
                        break;
						
					case "11":
                          $destinationAddress= $userResponse;
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 12 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET locationAddress='".$destinationAddress."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                                             
                          
						       
					$response= "END Details Received! Thanks";
                    
                    echo $response;
                    
                        break;
					
		
           
           
} 



}
}
?>
<?php

use AfricasTalking\SDK\AfricasTalking;
require 'vendor/autoload.php';

//Ensures this code runs only after a POST from AT

//remeber to return to if(!empty($_POST))
if(empty(!$_POST)) {

require_once('config.php'); // AT configuration file
require_once('dbConnector.php'); //Connects to database
require_once('AfricasTalking.php'); //AT Gateway
require_once('Service.php');
require_once('Response.php'); //File containing all resposes to user
require_once('Payments.php'); //AT Payments
require_once('SMS.php'); //AT Sms
require_once('functions.php'); // App Functions

 
ini_set('error_log', 'ATussd-app-error.log');



// Reads the variables sent via POST from AT gateway


$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"];  
 

 
// Initialize the SDK
$AT = new AfricasTalking($username, $apiKey);



//Explode the text to get the value of the latest interaction - think 1*1
$textArray = explode('*', $text);
$userResponse = trim(end($textArray));

//Set the default level of the user
$menuNumber = 0;

//Check the level of the user from the DB and retain default level if none is found for this session
$sql = "SELECT menuNumber FROM session_levels WHERE sessionId ='".$sessionId."' LIMIT 1";
$menuNumberQuery = $db->query($sql);
if ($menuNumberQueryResult = $menuNumberQuery->fetch_assoc()) {
    $menuNumber = $menuNumberQueryResult['menuNumber'];
}


//Check if the user is registered in the database
$sql7 = "SELECT * FROM account WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1";
$userQuery = $db->query($sql7);
$userAvailable = $userQuery->fetch_assoc();

//Check if the user is available (no)->Register the user
if (!$userAvailable) {
    
	
	 $sq99 = "INSERT INTO account (phoneNumber) VALUES('".$phoneNumber."')";
     $db->query($sq99);
	
}


// Serve the Services Menu


if ($menuNumber == 0 || $menuNumber == 1) {
        switch ($userResponse) {
			
// Main Menu
            case "":
                if ($menuNumber == 0 ||$menuNumber == 1) {
                    
                 
                    //9b. Graduate user to next level & Serve Main Menu
                    $sql9b = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 1 )";
                    $db->query($sql9b);
					$sql9c = "INSERT INTO `transactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                    //Serve our services menu

                    // Print the response onto the page so that AT gateway can read it
                   
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Main'];
                }
                break;
                
            case "100":
            

// Update Session to the Next Level
                        $sql5 = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 200 )";
                        $db->query($sql5);

$sql9c = "INSERT INTO `transactions`( `phoneNumber`, `sessionId`, `ticketType`, `location`, `state`) VALUES('".$phoneNumber."', '".$sessionId."', 'Events', 'General Events', 'Lagos')";
                    $db->query($sql9c);


//insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
    
  // select all movies based on the Location the user chose

                        $sql1 = "SELECT * FROM events JOIN location ON events.location = location.locationName Where events.location = 'General Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                        $queryResult= $db->query($sql1);


                        //Display Movies

                        if ($queryResult->num_rows > 0) {

                        $menuResult = $queryResult->fetch_all();


                        $menu = serialize($menuResult);




                        //Update the orders table with the Movies List(Store) results into the ordertable
                        $sql1d="UPDATE orders SET menu ='".$menu."'  WHERE sessionId = '".$sessionId."'";
                        $db->query($sql1d);
                        // output data of each row

                        $itemCount = 0;
                        	
                        echo "CON ";

                        if($menuResult){

                        foreach($menuResult as $Menu ) {


                        echo $itemCount.'. ';

                        echo $Menu['1']."\n";
                                                        
                        $itemCount++;

                        } 


                        }	




                        } else {
                        echo "END No available Movies. Try again Later";
                        }



                        
	



                break;
                
                
            case "0":
                if ($menuNumber == 1) {

                    $sql00 = "INSERT INTO session_levels`(`sessionId`,`phonenumber`,`menuNumber`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                    $db->query($sql00);
					$sql9c = "INSERT INTO `transactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                    //9c. Send the user Request Service Menu

                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Main'];
                }
                break;
            case "1":
                if ($menuNumber == 1) {

                    $sql01 = "UPDATE session_levels SET  menuNumber=10 WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01);
					$sql01a = "UPDATE transactions SET  ticketType = 'Movies' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
					
                   
                    // Print the response onto the page so that AT gateway can read it
                    
                    echo $responseMsg['Locations'];
                }
                break;
            case "2":
                if ($menuNumber == 1) {

                    $sql02 = "UPDATE session_levels SET menuNumber =20 WHERE sessionId = '".$sessionId."'";
                    $db->query($sql02);
					
					$sql01a = "UPDATE transactions SET  ticketType = 'Events' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
                  


                    // Print the response onto the page so that AT gateway can read it
                 
                 
                     echo $responseMsg['Locations'];
                }
                break;
			case "3":
				if ($menuNumber == 1) {

					$sql02 = "UPDATE session_levels SET menuNumber =800 WHERE sessionId = '".$sessionId."'";
					$db->query($sql02);
				


					// Print the response onto the page so that AT gateway can 
					
					echo "CON Enter your Transaction ID:";
				}
				break;	
				
//Feet & Tricks				
			case "WEASD":

 if($menuNumber== 1){
     
//Check if the user is registered in the database
$sql7 = "SELECT * FROM tf_reg WHERE phonenumber LIKE '%".$phoneNumber."%' LIMIT 1";
$userQuery = $db->query($sql7);
$userAvailable = $userQuery->fetch_assoc();


//Check if the user is available (no)->Register the user
if (!$userAvailable) {


// Serve the Services Menu


			       
                        //Save Phone Number, Maintain session
			        	//9b. Graduate user to next level & Serve Main Menu
			        	$sql9b = "UPDATE session_levels SET  menuNumber=51 WHERE sessionId = '".$sessionId."' ";
			         $db->query($sql9b);
	


			        	//Serve our services menu
						$response = "CON Welcome to Feet N Tricks Registration, Please select your location:\n";
						$response .= " 1. Lagos\n";
						$response .= " 2. Abuja\n";
						$response .= " 3. Owerri\n";
						$response .= " 4. Warri\n";							
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;						
			        } elseif ($userAvailable['fullname']==""){
    
    //9b. Graduate user to next level & Serve Main Menu
			        		$sql9 = "UPDATE session_levels SET  menuNumber=52 WHERE sessionId = '".$sessionId."' ";
			        	$db->query($sql9);
    
    	//Serve our services menu
						$response = "CON Please enter your full name:\n";
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;	
 			  			
    
}
	else {
	    echo "END You have alredy registered! Thank You.";
	    
	}}
			        break;
				
		case "4":
		    
		    //9b. Graduate user to next level & Serve Main Menu
			        	$sql9b = "UPDATE session_levels SET  menuNumber=41 WHERE sessionId = '".$sessionId."' ";
			         $db->query($sql9b);
			         
			 $sql9c = "INSERT INTO `anike_natural_transactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
		    
		    if($menuNumber == 1 ||$menuNumber == 0){
		        
		      echo $responseMsg['ABS_MENU_1'];
		    }
		    
		    
		    break;
		    
		    
            default:
                if ($menuNumber == 1 ||$menuNumber == 0 ) {
                    // Return user to Main Menu & Demote user's level
                   
                    //demote
                    $sqlMenuDemote = "UPDATE session_levels SET menuNumber`=0 WHERE sessionId`='".$sessionId."'";
                    $db->query($sqlMenuDemote);

                    // Print the response onto the page so that AT gateway can read it
                    echo $responseMsg['Error_On_Main'];
                }break;
        }
    }else {
        switch ($menuNumber) {
            
//Anike Naturals

	case"41":
            //List of Products 
				switch ($userResponse) {
				// Receive Bank Code and Save Bancode, Ask for DOB
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN001' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
						
					case "2":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN003' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "3":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN005' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN009' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN002' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "6":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN004' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "7":
                        
								//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='AN006' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
					case "8":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 42 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET  productCode ='AN007' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo "CON Please enter your shipping address(Lagos Only):";
                        break;
				
						
					case "0":
                        	//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 41 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Product Code
                            $sqla = "UPDATE anike_natural_transactions SET productCode='0' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							 echo $responseMsg['ABS_MENU_2'];
							
                        break;
                        
                    default:
                       
                    
                            // Print the response onto the page so that AT gateway can read it
                          
                           echo $responseMsg['ABS_MENU_1'];
                      
                        break;
				
				}
					break;
					
					
case "42":
    
    // save address and show payments
    $shippingAddress =$userResponse;
    //Save Shipping Address
                            $sqla = "UPDATE anike_natural_transactions SET shippingAdress='".$shippingAddress."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
    
    	//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 43 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							
             echo $responseMsg['Banks']; 
    break;
    
 case"43":
            //List of Banks Menu 
				switch ($userResponse) {
			
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 44 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET bankCode='234003' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo $responseMsg['Account_Number'];
								
                        break;
						
					case "2":
                        
						
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 44 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET bankCode =234001 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Number'];
								
                        break;
					case "3":
                        
						
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 44 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET bankCode=234010 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Number'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 441 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET bankCode=234002 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo "CON Enter your Date of Birth (YYYY-MM-DD)";
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 44 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET bankCode =234007 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Number'];
								
                        break;
					
                        
                    default:
                       
                    
                            // Print the response onto the page so that AT gateway can read it
                          
                           echo $responseMsg['Banks'];
                      
                        break;
				
				}
					break;	
					
	case"441":
	    
	    $dateOfBirth = $userResponse;
	    
	    	//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 44 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE anike_natural_transactions SET dateOfBirth='".$dateOfBirth."'  WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Number'];
	    
	break;
				
    
    case"44":
		
			  $accountNumber = $userResponse;
			  
			if( is_numeric($accountNumber) && strlen((string)$accountNumber)==10){

			  if ($menuNumber == 44) {
			      
			 

				$sql = "UPDATE session_levels SET menuNumber =45  WHERE sessionId = '".$sessionId."'";
				$db->query($sql);
				
				 
				$sql1 = "UPDATE anike_natural_transactions SET accountNumber ='".$accountNumber."' WHERE sessionId = '".$sessionId."'";
				$db->query($sql1);
				
				
				echo $responseMsg['Account_Name'];
			}}else{
			    //Ask for Account Number
			        $response = "CON Please enter a valid Account Number:";
					
					echo $response; 
			}
                  break;

case"45":
    //Store Account Name, and Serve Payment Notice
			
                $accountName = $userResponse; 
             	if (preg_match ("/^[a-zA-Z\s]+$/",$accountName)){
			
			
				if ($menuNumber == 45) {
						
					$accountName = $userResponse;
					// Save Account_Name to DB
					$sqla = "UPDATE anike_natural_transactions SET accountName = '".$accountName."' WHERE sessionId = '".$sessionId."'";
					$db->query($sqla);
					
					//Update Session
					$sql00 = "UPDATE session_levels SET menuNumber =46  WHERE sessionId = '".$sessionId."'";
					$db->query($sql00);
				}
							
    
    echo "CON You will be charged Delivery fee: N1000 (Enter 1 to continue, 0 to skip)";
             	}else{
			        echo "CON Please enter a valid Account Name:";
			    }
    break;

   case"46":
		
		if ($userResponse==0 || $userResponse==1){
					//Update Session
					$sql0 = "UPDATE session_levels SET menuNumber =47  WHERE sessionId = '".$sessionId."'";
					$db->query($sql0);
							
					// Get and Notify User of the Ticket Details.
					
					 
			      $sql1b = "SELECT productCode FROM `anike_natural_transactions` WHERE sessionId = '".$sessionId."'";
                $queryResult= $db->query($sql1b);
                $productCoderesult = mysqli_fetch_assoc($queryResult);
                
                $productCode = $productCoderesult['productCode'];
                
              
                $sql1c = "SELECT * FROM `anike_natural_products` WHERE productCode = '".$productCode."'";
                $ProductQueryResult= $db->query($sql1c);
               $productQueryResult = mysqli_fetch_assoc($ProductQueryResult);


                 $productName = $productQueryResult['productName'];
                 $price = $productQueryResult['price'];
                 
                 
                    $response = "CON You will be charged N".$price;
					$response .= " for ".$productName."";
					$response .= "+ N100 service charge";
					$response .= " Press 1 to continue \n";
				
				
				if($userResponse==1){
				    
					$updatedPrice = $price + 1100;
					
					echo $response;
				}
				
				if($userResponse==0){
				    
					$updatedPrice = $price + 100;
					echo $response;
					
				}
				
					// Save Account_Name to DB
					$sqlb = "UPDATE anike_natural_transactions SET charge = '".$updatedPrice."' WHERE sessionId = '".$sessionId."'";
					$db->query($sqlb);
				
				    
				}else{
				    echo "CON Invalid Input!\nYou will be charged Delivery fee: N1000 (Enter 1 to continue, 0 to skip)";
				}
				
				
					
		  
				break;

    
	case"47":
			// Processes the Payments
			 switch ($userResponse) {
                    case "1":
                        
                        if ($menuNumber=47){
							
						// Select details from the DB
						$sql="SELECT * FROM anike_natural_transactions WHERE sessionId ='".$sessionId."'";
						$queryResult=$db->query($sql);
						
						
                        // output data of  row
                         while ($result = mysqli_fetch_assoc($queryResult)) {
                        
						//Bank Details
							$accountNumber =$result['accountNumber'];
                            $bankCode = floatval($result['bankCode']);
                            $dateOfBirth = $result['dateOfBirth'];
							$charge =$result['charge'];
							 $accountName = $result['accountName'];
							  $productCode = $result['productCode'];
                         }
						
					
                        
				
                            
                        
                        // Get the payments service
                        $payments   = $AT->payments();
                        
                        // Set the name of your Africa's Talking payment product
                        $productName = "Smartpay";
                        
                        // Set the details of the bank account to be charged
                        $bankAccount = [
                            "accountName" => $accountName,
                            "accountNumber" => $accountNumber,
                            "bankCode"      => $bankCode,
                            "dateOfBirth" => $dateOfBirth ];
                        
                        // Set The 3-Letter ISO currency code and the checkout amount
                        $currencyCode       = "NGN";
                        $amount             = $charge;
                        
                        // Set a description of the transaction to be displayed on the
                        // clients statement
                        $narration          = "Anike Natuals Purchase: ";
                        $narration          .=$productCode;
                        
                        // Set any metadata that you would like to send along with this request.
                        // This metadata will be included when we send back the final payment notification
                        $metadata = [
                            "agentId"   => "654",
                            "productId" => "1388"
                        ];
                        
                       
                        
                        // That's it, hit send and we'll take care of the rest
                        try {
                            $checkoutResult = $payments->bankCheckoutCharge([
                                "productName"  => $productName,
                                "bankAccount"  => $bankAccount,
                                "currencyCode" => $currencyCode,
                                "amount"       => $amount,
                                "narration"    => $narration,
                                "metadata"     => $metadata
                            ]);
                        
                       
                                   
                                 
                                  $checkoutResultdData =$checkoutResult['data'];
                                   
                                   $checkoutResultdDataArray =(array)$checkoutResultdData;
                                   
                                   $description= $checkoutResultdDataArray['description'];
                                   

                                   
                                   $paymentStatus= $checkoutResultdDataArray['status'];
                                                    
                                       
                                   $transactionId = $checkoutResultdDataArray['transactionId'];
                                   
                                 
                                              
                                     echo "CON ";
                                     echo $description;
                                    
                                    
                                    
        
        // Save Payment Response
			$sqlf = "UPDATE anike_natural_transactions SET comment = '".$paymentStatus."', atTransactionId = '".$transactionId."' , description = '".$description."' WHERE sessionId = '".$sessionId."'";
					$db->query($sqlf);
					
        
                             	//Update Session
					$sql00 = "UPDATE session_levels SET menuNumber =48  WHERE sessionId = '".$sessionId."'";
					$db->query($sql00);      
                                   
                             
                                
                                
                        } catch(Exception $e) {
                            
                            echo "Error:".$e->getMessage();
                        
                            
                        }

                    
                    
                    
                        }
                           
                           break;
                           
                           
					default:
                      Echo "END Wrong Input!\nPlease Try again. Thank You!";
                       break;	
			
               
			   
          
			 }
			break;
			
			
	case "48":
	    
	    $otp= $userResponse;
	    
	    	// Select details from the DB
						$sql="SELECT * FROM anike_natural_transactions WHERE sessionId ='".$sessionId."'";
						$queryResult=$db->query($sql);
						
						// output data of  row
                         while ($result = mysqli_fetch_assoc($queryResult)) {
                        
						//Bank Details
							$transactionId =$result['atTransactionId'];
							$productName =$result['productName'];
                        
                         }
						
	   
// Get the payments service
$payments   = $AT->payments();

// Set the transactionId you got from the
// bank checkout charge request


// That's it, hit send and we'll take care of the rest
try {
    $result = $payments->bankCheckoutValidate([
        "transactionId" => $transactionId,
        "otp"           => $otp
    ]);
                                  $validationResultData =$result['data'];
                                   
                                   $validationResultdDataArray =(array)$validationResultData;
                                   
                                   $description= $validationResultdDataArray['description'];
                                   
                                   
                                   $validationStatus= $validationResultdDataArray['status'];

                                 
                                              
                                     echo "END ".$validationStatus.":\n ".$description;


	$sqlfw = "UPDATE anike_natural_transactions SET comment = '".$validationStatus."', description = '".$description."' WHERE sessionId = '".$sessionId."'";
			$db->query($sqlfw);
			
			

 if($validationStatus =="Success"){

			          	//send SMS
                            // Get the SMS service
                                    $sms        = $AT->sms();
                                    
                                    // Set the numbers you want to send to in international format
                                    $recipients = $phoneNumber;
                                    
                                
                                    // Set your message
                                    $message     =  "Product: '".$productName."'Thank you for choosing Anike Natural. Delivery takes 2-4 working days. Kindly contact us on 08124875280 for complains or further enquiries.";

                                    
                                    
                                    
                                    
                                    // Set your shortCode or senderId
                                    $from       = "Smartticket";
                                    
                                    try {
                                        // Thats it, hit send and we'll take care of the rest
                                        $result = $sms->send([
                                            'to'      => $recipients,
                                            'message' => $message,
                                            'from'    => $from
                                        ]);
                                    
                                        
                                      
                                        
                                    } catch (Exception $e) {
                                        
                                        echo "Error: ".$e->getMessage();
                                        
                                    }
                                

}






} catch (Exception $e) {
    echo "Error: ".$e->getMessage();
}
	   
	  
	    break;
			
 
            
//Feet & Tricks Menu

case "51":
			        if($menuNumber==51){
                        //Save Location, Maintain session
                      switch ($userResponse) {

                          case "1":
                        
			        
			        	//9b. Graduate user to next level & Serve Main Menu
			        	$sql9 = "UPDATE session_levels SET  menuNumber=52 WHERE sessionId = '".$sessionId."' ";
			        	$db->query($sql9);
			        	
			        	
			        	 $sq99 = "INSERT INTO tf_reg (phonenumber,location) VALUES('".$phoneNumber."', 'Lagos')";
                        $db->query($sq99);
			        	
                    
			        	//Serve our services menu
						$response = "CON Please enter your full name:\n";
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;	
                          break;
                          case "2":
                          //9b. Graduate user to next level & Serve Main Menu
			        	//9b. Graduate user to next level & Serve Main Menu
			        	$sql9 = "UPDATE session_levels SET  menuNumber=52 WHERE sessionId = '".$sessionId."' ";
			        	$db->query($sql9);
			        	
			        		
			        	 $sq99 = "INSERT INTO tf_reg (phonenumber,location) VALUES('".$phoneNumber."', 'Abuja')";
                        $db->query($sq99);
			        	
			        	
			        	

                    
			        	//Serve our services menu
						$response = "CON Please enter your full name:\n";
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;	
                          break;
                          case "3":
                          //9b. Graduate user to next level & Serve Main Menu
			        		$sql9 = "UPDATE session_levels SET  menuNumber=52 WHERE sessionId = '".$sessionId."' ";
			        	$db->query($sql9);
			        	
			        	
			        	 $sq99 = "INSERT INTO tf_reg (phonenumber,location) VALUES('".$phoneNumber."', 'Owerri')";
                        $db->query($sq99);

                    
			        	//Serve our services menu
						$response = "CON Please enter your full name:\n";
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;	
                          break;
                          case "4":
                          //9b. Graduate user to next level & Serve Main Menu
			        		$sql9 = "UPDATE session_levels SET  menuNumber=52 WHERE sessionId = '".$sessionId."' ";
			        	$db->query($sql9);
			        	
			        	
			        	
			        	 $sq99 = "INSERT INTO tf_reg (phonenumber,location) VALUES('".$phoneNumber."', 'Warri')";
                        $db->query($sq99);

                    
			        	//Serve our services menu
						$response = "CON Please enter your full name:\n";
						
			  			// Print the response onto the page so that our gateway can read it
			  			header('Content-type: text/plain');
 			  			echo $response;	
                          break;
                      }}
                   
			        break;	
			        
			        
			        
			 case "52":
			        if($menuNumber==52){
                        //Save Full Name, Send SMS
                         $fullname = $userResponse;
                         
                        

                         $sql9b = "UPDATE tf_reg SET  fullname='".$fullname."' WHERE phonenumber LIKE '%".$phoneNumber."%' ";
			        	$db->query($sql9b);
			        	
			        	
			        	$sql7 = "SELECT ID FROM tf_reg WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1";
$userQuery = $db->query($sql7);
$userAvailable = $userQuery->fetch_assoc();

$id=$userAvailable['ID'];
$ticketid = "FF".$id;
			        	
			        	
			          
			          	//send SMS
                            // Get the SMS service
                                    $sms        = $AT->sms();
                                    
                                    // Set the numbers you want to send to in international format
                                    $recipients = $phoneNumber;
                                    
                                
                                    // Set your message
                                    $message     = "Thank you for registering for #AFFC2019. Your ticket ID is:".$ticketid.".  Venue: Balmoral convention center, federal palace hotel. 6-8 Ahmadu Bello way, Victoria Island, Lagos. Date: 14th- 15th September 2019. Time: 9am";
                                    
                                    // Set your shortCode or senderId
                                    $from       = "Smartticket";
                                    
                                    try {
                                        // Thats it, hit send and we'll take care of the rest
                                        $result = $sms->send([
                                            'to'      => $recipients,
                                            'message' => $message,
                                            'from'    => $from
                                        ]);
                                    
                                        
                                        if ($result['status'] == "success"){
                                            
                                            echo "END Thanks for registering. You will receive an SMS.\n";
                                            
                                        }
                                        
                                    } catch (Exception $e) {
                                        
                                        echo "Error: ".$e->getMessage();
                                        
                                    }
                                
            
                }



			        
			        break;
			

			
// Other Menu
					
            case"10":
			//Movies Tickets Location Menu
               switch ($userResponse) {
                    case "1":
                        //Lagos Locations
                        
                        if ($menuNumber = 10) {
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                           	$sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Lagos' AND events.eventType='Movies' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
							
							
							if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
								// output data of each row

                                $itemCount = 0;
											
								echo "CON ";
								
								
								
							foreach($menuResult as $Menu ) {
						 
							   
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
									                                    
							    $itemCount++;
								}
							//For Previous Menu
						   
                            echo "9. Back\n";
								
						
								
							} else {
								echo "END No available Movies. Try again Later";
							}
							
								
						
                           
						   	// Update transactions table
							$sql01a = "UPDATE transactions SET  state = 'Lagos' WHERE sessionId = '".$sessionId."' ";
							$db->query($sql01a);
                                             
                           
                        }
                        
                       break;
                    case "2":
                    //PH Movies Locations


                        if ($menuNumber = 10) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Rivers' AND events.eventType='Movies' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Movies. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'Rivers' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }


                       break;
                    case "3":
                    //Abuja Movies Locations
                        if ($menuNumber = 10) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'FCT' AND events.eventType='Movies' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Movies. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'FCT' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }

                       break;
                    case "9":
                     //Back to Main Menu
                        if ($menuNumber = 10) {

							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNumber = 1 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                            
                      
                            header('Content-type: text/plain');
							echo $responseMsg['Main'];
                        }
                        break;
                  
                    case "10":
                     // Invalid Selection Menu Control
                        
                        if ($menuNumber = 10) {

                        $sql01 = "UPDATE session_levels SET  menuNumber=11 WHERE sessionId = '".$sessionId."' ";
                        $db->query($sql01);



                        echo $responseMsg['Locations'];
                        }
                        break;

                        default:
                        // for Invalid User Inputs.
                        if ($menuNumber = 10) {
                        // Return user to Main Menu & Demote user's level
                        $response = "CON Invalid Entry.\n";
                        $response .= "Enter 10 to go back.\n";
                        //demote
                        $sqlMenuDemote = "UPDATE session_levels SET menuNumber=10 WHERE sessionId`='".$sessionId."'";
                        $db->query($sqlMenuDemote);

                        // Print the response onto the page so that AT gateway can read it

                        echo $response;

                        }
                        break;

                        }
                        break;
           
		    case"11":
                //Available Locations Menu for Movies Based on State 
                    switch ($userResponse) {
                        case "0":
                        case "1":
                        case "2":
                        case "3":
                        case "4":
                        case "5":
                        case "6":
                        case "7":
                        case "8":
                        case "10":

                        if ($menuNumber = 11) {

                        //User Response with Choice of Location
                        $selectedLocation = $userResponse;

                        // Update Session to the Next Level
                        $sql = "UPDATE session_levels SET menuNumber =200  WHERE sessionId = '".$sessionId."'";
                        $db->query($sql);


                        //Get the Stored Location Menu Displayed to User to get the exact location that the user cho0se


                        $sql11 = "SELECT * FROM orders WHERE sessionId = '".$sessionId."'";
                        $queryResult= $db->query($sql11);

                        $result = $queryResult->fetch_assoc();



                        $menu =	$result['location'];




                        $menu = unserialize($menu) ; 



                        $location = $menu[$selectedLocation][0];





                        /* Update the transaction table with the Users Choice of Location */

                        $sql1 = "UPDATE transactions SET location ='".$location."' WHERE sessionId ='".$sessionId."'";

                        $db->query($sql1);





                        // select all movies based on the Location the user chose

                        $sql1 = "SELECT * FROM events JOIN location ON events.location = location.locationName Where events.location = '".$location."' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                        $queryResult= $db->query($sql1);


                        //Display Movies

                        if ($queryResult->num_rows > 0) {

                        $menuResult = $queryResult->fetch_all();


                        $menu = serialize($menuResult);




                        //Update the orders table with the Movies List(Store) results into the ordertable
                        $sql1d="UPDATE orders SET menu ='".$menu."'  WHERE sessionId = '".$sessionId."'";
                        $db->query($sql1d);
                        // output data of each row

                        $itemCount = 0;
                        	
                        echo "CON ";

                        if($menuResult){

                        foreach($menuResult as $Menu ) {


                        echo $itemCount.'. ';

                        echo $Menu['1']."\n";
                                                        
                        $itemCount++;

                        } 


                        }	




                        } else {
                        echo "END No available Movies. Try again Later";
                        }



                        }


                        break;
				
					
                        case "9":
                            if ($menuNumber = 11) {

    							// Update Session
                                $sql = "UPDATE session_levels SET menuNumber = 10 WHERE sessionId = '".$sessionId."'";
                                $db->query($sql);
    							
                               // Back to Previous Menu
                                echo $responseMsg['Locations'];
                            }
                            break;
                            
                      
                    
                         default:
                        if ($menuNumber = 11) {
                            // Return user to Main Menu & Demote user's level
                            $response = "CON You have to choose a service.\n";
                            $response .= "Press 10 to go back.\n";
                            //demote
                            $sqlMenuDemote = "UPDATE session_levels SET menuNumber=11 WHERE sessionId`='".$sessionId."'";
                            $db->query($sqlMenuDemote);

                            // Print the response onto the page so that AT gateway can read it
                            header('Content-type: text/plain');
                            echo $response;
                            
                        }
                        break;
               }
                break;
           
			 case"20":
            //Events Tickets Location Menu
               switch ($userResponse) {
                    case "1":
                        //Lagos Events Locations
                        
                        if ($menuNumber = 20) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 21 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Lagos' AND events.eventType='Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Events. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'Lagos' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }
                        
                       break;
                    case "2":
                    //PH Events Locations

                        if ($menuNumber = 20) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 21 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Rivers' AND events.eventType='Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Events. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'Rivers' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }
                        
                       break;
                    case "3":
                    //Abuja Events Locations
                        if ($menuNumber = 20) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 21 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'FCT' AND events.eventType='Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Events. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'FCT' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }
                        

                       break;
                       
                        case "4":
                    //Asaba Events Locations

                        if ($menuNumber = 20) {
                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 21 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
                           
                            $sql1 = "SELECT DISTINCT locationName FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Delta' AND events.eventType='Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            
                            $queryResult= $db->query($sql1);
                            
                            
                            if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $location = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`location`, `sessionId`) VALUES ('".$location."','".$sessionId."')";
                                $db->query($sql11);
                                // output data of each row

                                $itemCount = 0;
                                            
                                echo "CON ";
                                
                                
                                
                            foreach($menuResult as $Menu ) {
                         
                               
                               echo $itemCount.'. ';
                               
                               echo $Menu['0']."\n";
                                                                        
                                $itemCount++;
                                }
                            //For Previous Menu
                           
                            echo "9. Back\n";
                                
                        
                                
                            } else {
                                echo "END No available Events. Try again Later";
                            }
                            
                                
                        
                           
                            // Update transactions table
                            $sql01a = "UPDATE transactions SET  state = 'Rivers' WHERE sessionId = '".$sessionId."' ";
                            $db->query($sql01a);
                                             
                           
                        }
                        
                       break;
                       
                       
                       
                    case "9":
                     //Back to Main Menu
                        if ($menuNumber = 20) {

                            //UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNumber = 1 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                            
                      
                            header('Content-type: text/plain');
                            echo $responseMsg['Main'];
                        }
                        break;
                  
                    case "10":
                     // Invalid Selection Menu Control
                        
                        if ($menuNumber = 20) {

                        $sql01 = "UPDATE session_levels SET  menuNumber=21 WHERE sessionId = '".$sessionId."' ";
                        $db->query($sql01);



                        echo $responseMsg['Locations'];
                        }
                        break;

                    default:
                        // for Invalid User Inputs.
                        if ($menuNumber = 20) {
                        // Return user to Main Menu & Demote user's level
                        $response = "CON Invalid Entry.\n";
                        $response .= "Enter 10 to go back.\n";
                        //demote
                        $sqlMenuDemote = "UPDATE session_levels SET menuNumber=20 WHERE sessionId`='".$sessionId."'";
                        $db->query($sqlMenuDemote);

                        // Print the response onto the page so that AT gateway can read it

                        echo $response;

                        }
                        break;

                        }
                        break;
           
            case"21":
            //  //Available Locations Menu for Events Based on State
                    switch ($userResponse) {
                        case "0":
                        case "1":
                        case "2":
                        case "3":
                        case "4":
                        case "5":
                        case "6":
                        case "7":
                        case "8":
                        case "10":

                        if ($menuNumber = 21) {

                        //User Response with Choice of Location
                        $selectedLocation = $userResponse;

                        // Update Session to the Next Level
                        $sql = "UPDATE session_levels SET menuNumber =200  WHERE sessionId = '".$sessionId."'";
                        $db->query($sql);


                        //Get the Stored Location Menu Displayed to User to get the exact location that the user cho0se


                        $sql11 = "SELECT * FROM orders WHERE sessionId = '".$sessionId."'";
                        $queryResult= $db->query($sql11);

                        $result = $queryResult->fetch_assoc();



                        $menu = $result['location'];




                        $menu = unserialize($menu) ; 



                        $location = $menu[$selectedLocation][0];





                        /* Update the transaction table with the Users Choice of Location */

                        $sql1 = "UPDATE transactions SET location ='".$location."' WHERE sessionId ='".$sessionId."'";

                        $db->query($sql1);





                        // select all movies based on the Location the user chose

                        $sql1 = "SELECT * FROM events JOIN location ON events.location = location.locationName Where events.location = '".$location."' AND events.eventType='Events' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                        $queryResult= $db->query($sql1);


                        //Display Movies

                        if ($queryResult->num_rows > 0) {

                        $menuResult = $queryResult->fetch_all();


                        $menu = serialize($menuResult);




                        //Update the orders table with the Movies List(Store) results into the ordertable
                        $sql1d="UPDATE orders SET menu ='".$menu."'  WHERE sessionId = '".$sessionId."'";
                        $db->query($sql1d);
                        // output data of each row

                        $itemCount = 0;
                            
                        echo "CON ";

                        if($menuResult){

                        foreach($menuResult as $Menu ) {


                        echo $itemCount.'. ';

                        echo $Menu['1']."\n";
                                                        
                        $itemCount++;

                        } 


                        }   




                        } else {
                        echo "END No available Events. Try again Later";
                        }



                        }


                        break;
                
                    
                        case "9":
                            if ($menuNumber = 21) {

                                // Update Session
                                $sql = "UPDATE session_levels SET menuNumber = 10 WHERE sessionId = '".$sessionId."'";
                                $db->query($sql);
                                
                               // Back to Previous Menu
                                echo $responseMsg['Locations'];
                            }
                            break;
                            
                      
                    
                         default:
                        if ($menuNumber = 21) {
                            // Return user to Main Menu & Demote user's level
                            $response = "CON You have to choose a service.\n";
                            $response .= "Press 10 to go back.\n";
                            //demote
                            $sqlMenuDemote = "UPDATE session_levels SET menuNumber=21 WHERE sessionId`='".$sessionId."'";
                            $db->query($sqlMenuDemote);

                            // Print the response onto the page so that AT gateway can read it
                            header('Content-type: text/plain');
                            echo $response;
                            
                        }
                        break;
               }
                break;


            case"200":
			//Movies/Events Menu
                switch ($userResponse) {
                case "0":
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":

                    $selectedRequest = $userResponse;

                    if ($menuNumber = 200) {

                    $sql11 = "SELECT menu FROM orders WHERE sessionId = '".$sessionId."'";
                    $queryResult= $db->query($sql11);
                    $result = mysqli_fetch_assoc($queryResult);
                    $menu =	$result['menu'];
                    $menu = unserialize($menu) ;



                    $requestType = $menu[$selectedRequest][1];
                    $price = $menu[$selectedRequest][3];



                    $sql = "UPDATE session_levels SET menuNumber =91  WHERE sessionId = '".$sessionId."'";
                    $db->query($sql);


                    $sql1 = "UPDATE transactions SET requestType ='".$requestType."', charge ='".$price."' WHERE sessionId = '".$sessionId."'";
                    $db->query($sql1);


                    echo $responseMsg['Account_Number'];
                    }
                    break;

                default:
                    if ($menuNumber = 200) {
                    // Return user to Main Menu & Demote user's level
                    $response = "END Invalid response.\n";
                    $response .= "Please Try Again.\n";
                    //demote
                    $sqlMenuDemote = "UPDATE session_levels SET menuNumber=200 WHERE sessionId`='".$sessionId."'";
                    $db->query($sqlMenuDemote);

                    // Print the response onto the page so that AT gateway can read it

                    echo $response;

                    }
                break;
                }
                
            break;
		

// Payments Section			
					
			case"91":
		
			  $accountNumber = $userResponse;
			  
			if( is_numeric($accountNumber) && strlen((string)$accountNumber)==10){

			  if ($menuNumber = 91) {
			      
			     

				$sql = "UPDATE session_levels SET menuNumber =95  WHERE sessionId = '".$sessionId."'";
				$db->query($sql);
				
				 
				$sql1 = "UPDATE transactions SET accountNumber ='".$accountNumber."' WHERE sessionId = '".$sessionId."'";
				$db->query($sql1);
				
				
				echo $responseMsg['Banks'];
			}}else{
			    //Ask for Account Number
			        $response = "CON Please enter a valid Account Number:";
					
					echo $response; 
			}
                  break;
				
				
			case"95":
            //List of Banks Menu 
				switch ($userResponse) {
			
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode='234003' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo $responseMsg['Account_Name'];
								
                        break;
						
					case "2":
                        
						
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234001 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "3":
                        
						
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234010 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 92 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234002 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo "CON Enter your Date of Birth (YYYY-MM-DD)";
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234007 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					
                        
                    default:
                       
                    
                            // Print the response onto the page so that AT gateway can read it
                          
                           echo $responseMsg['Banks'];
                      
                        break;
				
				}
					break;	
				
				
				
				
					case"92":
		
			         $dateOfBirth = $userResponse;
			  

			  if ($menuNumber = 92) {
			      
			     

				$sql = "UPDATE session_levels SET menuNumber =902  WHERE sessionId = '".$sessionId."'";
				$db->query($sql);
				
				 
				$sql1 = "UPDATE transactions SET dateOfBirth ='".$dateOfBirth."' WHERE sessionId = '".$sessionId."'";
				$db->query($sql1);
				
				header('Content-type: text/plain');
				echo $responseMsg['Account_Name'];
			}
			
                  break;
				
				
			
			
			
				
			case"98":
            //List of Banks Menu (1)
				switch ($userResponse) {
				// Receive Bank Code and Save Bancode, Ask for DOB
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode='234003' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
						
							echo $responseMsg['Account_Name'];
								
                        break;
						
					case "2":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234012 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							
							echo $responseMsg['Account_Name'];
								
                        break;
					case "3":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234005 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234022 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234001 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "6":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234014 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "7":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234004 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "8":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234015 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "9":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234016 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;	
						
					case "0":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 99 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
						                                           
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Banks2'];
								
                        break;
                        
                    default:
                       
                    
                            // Print the response onto the page so that AT gateway can read it
                          
                           echo $responseMsg['Banks'];
                      
                        break;
				
				}
					break;
				
			case"99":
            //List of Banks Menu (2)
				switch ($userResponse) {
				// Receive Bank Code and Save Bancode, Ask for Account Name
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234017 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
						
					case "2":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234009 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "3":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234010 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234020 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234019 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "6":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234008 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "7":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234021 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					case "8":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234002 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
					
						
					case "0":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 98 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
						                                           
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Banks'];
								
                        break;
                    
                     default:
                       
                    
                            // Print the response onto the page so that AT gateway can read it
                          
                           echo $responseMsg['Banks2'];
                      
                        break;
				
				}
					break;
		
			case"902":
			 //Store Account Name, and Serve Payment Notice
			
                $accountName = $userResponse; 
             	if (preg_match ("/^[a-zA-Z\s]+$/",$accountName)){
			
			
				if ($menuNumber == 902) {
						
					$accountName = $userResponse;
					// Save Account_Name to DB
					$sqla = "UPDATE transactions SET accountName = '".$accountName."' WHERE sessionId = '".$sessionId."'";
					$db->query($sqla);
					
					//Update Session
					$sql00 = "UPDATE session_levels SET menuNumber =999  WHERE sessionId = '".$sessionId."'";
					$db->query($sql00);
							
							
					// Get and Notify User of the Ticket Details.
					
					 
			      $sql1b = "SELECT * FROM `transactions` WHERE sessionId = '".$sessionId."'";
                $queryResult= $db->query($sql1b);
                $result = mysqli_fetch_assoc($queryResult);
                
              

                 $requestType = $result['requestType'];
                 $price = $result['charge'];
                 
                 
                    $response = "CON You will be charged N".$price;
					$response .= " for ".$requestType.".";
					$response .= " Press 1 to continue \n";
					
					

							
					// Print the response onto the page so that AT gateway can read it
                   
                   
                    echo $response;
                    
                    
               
                
			
					}
			    }else{
			        echo "CON Please enter a valid Account Name:";
			    }
			   
				break;
			
			case"999":
			// Processes the Payments
			 switch ($userResponse) {
                    case "1":
                        
                        if ($menuNumber=999){
							
						// Select details from the DB
						$sql="SELECT * FROM transactions WHERE sessionId ='".$sessionId."'";
						$queryResult=$db->query($sql);
						
						
						
						
                        // output data of  row
                         while ($result = mysqli_fetch_assoc($queryResult)) {
                        
						//Bank Details
							$accountNumber =$result['accountNumber'];
                            $bankCode = floatval($result['bankCode']);
                            $dateOfBirth = $result['dateOfBirth'];
							$charge =$result['charge'];
							 $accountName = $result['accountName'];
							  $requestType = $result['requestType'];
                         }
						
					
                        
				
                            
                        
                        // Get the payments service
                        $payments   = $AT->payments();
                        
                        // Set the name of your Africa's Talking payment product
                        $productName = "Smartpay";
                        
                        // Set the details of the bank account to be charged
                        $bankAccount = [
                            "accountName" => $accountName,
                            "accountNumber" => $accountNumber,
                            "bankCode"      => $bankCode,
                            "dateOfBirth" => $dateOfBirth ];
                        
                        // Set The 3-Letter ISO currency code and the checkout amount
                        $currencyCode       = "NGN";
                        $amount             = $charge;
                        
                        // Set a description of the transaction to be displayed on the
                        // clients statement
                        $narration          = "Smart Ticket Purchase: ";
                        $narration          .=$requestType;
                        
                        // Set any metadata that you would like to send along with this request.
                        // This metadata will be included when we send back the final payment notification
                        $metadata = [
                            "agentId"   => "654",
                            "productId" => "1388"
                        ];
                        
                       
                        
                        // That's it, hit send and we'll take care of the rest
                        try {
                            $checkoutResult = $payments->bankCheckoutCharge([
                                "productName"  => $productName,
                                "bankAccount"  => $bankAccount,
                                "currencyCode" => $currencyCode,
                                "amount"       => $amount,
                                "narration"    => $narration,
                                "metadata"     => $metadata
                            ]);
                        
                       

                              if ($checkoutResult['status'] == "success" ){
                                   
                                 
                                  $checkoutResultdData =$checkoutResult['data'];
                                   
                                   $checkoutResultdDataArray =(array)$checkoutResultdData;
                                   
                                   $description= $checkoutResultdDataArray['description'];
                                   
                                    
        
        
        $sql02 = "UPDATE session_levels SET menuNumber =700 WHERE sessionId = '".$sessionId."'";
                $db->query($sql02);
        
        
        
        
        
                                   
                                   $paymentStatus= $checkoutResultdDataArray['status'];
                                                    
                                   $t_ID = TicketId();    
                                   $transactionId = $checkoutResult['transactionId'];
                                   
                                   //Save Ticket Details to DB
                                   
                                   $sql01a = "UPDATE transactions SET  ticketId = '".$t_ID."', AT_Trasaction_ID='".$transactionId."', comment = '".$paymentStatus."' WHERE sessionId = '".$sessionId."' ";
                                    $db->query($sql01a);
                                   
                            /**     if($checkoutResultdDataArray['status']=="PendingValidation"){
                                     
                                     // Get the SMS service
                                            $sms        = $AT->sms();
                                            
                                            // Set the numbers you want to send to in international format
                                            $recipients = $phoneNumber;
                                            
                                        
                                            // Set your message
                                            $message     = "Your Transaction ID is ".$t_ID." Please Validate your purchase with the OTP Sent by your Bank to Complete Purchase.";
                                            
                                           
                                            // Set your shortCode or senderId
                                            $from       = "Smartticket";
                                            
                                            try {
                                                // Thats it, hit send and we'll take care of the rest
                                                $result = $sms->send([
                                                    'to'      => $recipients,
                                                    'message' => $message,
                                                    'from'    => $from
                                                ]);
                                            
                                               
                                               
                                               
                                            } catch (Exception $e) {
                                                
                                                echo "Error: ".$e->getMessage();
                                                
                                            }
                                      
                                   
                                     }  **/
                                                  
                                                  
                                     //Display Result to USer       
                                     echo "CON ";
                                     echo $description;
        
                                                  
                                                  
                                                        
                                }else{
                                    
                                   
                                    print_r($checkoutResult['status']);
                                   
                                }
                                
                                
                        } catch(Exception $e) {
                            
                            echo "Error:".$e->getMessage();
                        
                            
                        }

                    
                    
                    
                        }
                           
                           break;
                           
                           
					default:
                      Echo "END Thank You!";
                       break;	
			
               
			   
          
			 }
			break;
			 
			

// OTP Validation Section

			case"800":
			// Validate Service Request Via OTP
			 $ticketId = $userResPonse;
			
			 $sql02 = "UPDATE session_levels SET menuNumber =801 WHERE sessionId = '".$sessionId."'";
             $db->query($sql02);
			
			 $sql9b = "SELECT * FROM transactions WHERE ticketId= '".$ticketId."'";
            
             $queryResult= $db->query($sql9b);
            
                if ( $result = mysqli_fetch_assoc($queryResult)){
                
                     echo "CON Enter Your OTP:";
                    }
            
            
				
			 break;
			
			
			case"801":
			    
                $otp = $userResPonse;

                $sql02 = "UPDATE session_levels SET menuNumber =802 WHERE sessionId = '".$sessionId."'";
                $db->query($sql02);

                if(is_numeric($otp)){


                // Get the payments service
                $payments   = $AT->payments();

                // Set the transactionId you got from the
                // bank checkout charge request
                $transactionId =$ticketId ;



                // That's it, hit send and we'll take care of the rest
                try {
                $result = $payments->bankCheckoutValidate([
                "transactionId" => $transactionId,
                "otp"           => $otp
                ]);


                if($result['status']=="successs"){

                //Query Ticekt Details and Send SMS

                $sql9b = "SELECT * FROM transactions WHERE ticketId= '".$ticketId."'";
                $db->query($sql9b);

                // Get the SMS service
                $sms        = $AT->sms();

                // Set the numbers you want to send to in international format
                $recipients = $phoneNumber;


                // Set your message
                $message     = "Your Transaction ID is ".$t_ID." Please Validate your purchase with the OTP Sent by your Bank to Complete Purchase.";


                // Set your shortCode or senderId
                $from       = "Smartticket";

                try {
             //Thats it, hit send and we'll take care of the rest
                $result = $sms->send([
                'to'      => $recipients,
                'message' => $message,
                'from'    => $from
                ]);


                if ($result['status'] == "success"){

                echo "END Success!\nPlease Validate your Ticket Purchase with the OTP sent by your Bank!";

                }

                } catch (Exception $e) {

                echo "Error: ".$e->getMessage();

                }



                }else{
                echo "END Validation Error. Please try again!";
                }


                } catch (Exception $e) {
                echo "Error: ".$e->getMessage();
                }




                }

                break;
	
			
			
			
			
			
			case"700":
			    
			    echo "END ";
			    
			    echo $userResPonse;
			    
			    
			    
                $otpin = "123456";

              $sql="SELECT * FROM transactions WHERE sessionId ='".$sessionId."'";
			$queryResult=$db->query($sql);
						
						
						
						
            // output data of  row
             while ($result = mysqli_fetch_assoc($queryResult)) {
            
			//Bank Details
				$transactionId =$result['AT_Trasaction_ID'];
             }
						


                // Get the payments service
                $payments   = $AT->payments();

                // Set the transactionId you got from the
                // bank checkout charge request
                $transactionId ="" ;
                $otp = $userResPonse;


                // That's it, hit send and we'll take care of the rest
                try {
    $result = $payments->bankCheckoutValidate([
        "transactionId" => $transactionId,
        "otp"           => $otpin
    ]);
    
                    echo "END :";
                    echo $otpin;
                    echo ":::";
                    print_r($result);
                   
                    } catch (Exception $e) {
                        echo "Error: ".$e->getMessage();
                    }




                break;
			
			
			
			
			
			
			
			



			    	
			

           
           
} 


}
}

?>
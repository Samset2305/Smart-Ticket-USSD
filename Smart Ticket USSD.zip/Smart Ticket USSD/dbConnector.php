<?php 
//This files specifies the credentials to access your Database.
//Connection Credentials
$servername ="localhost";
$dbport =3306;
$userName = "inspires";
$password = "E4%5tmr5*2Ws";


$database = "inspires_ticket_system_db";

// Create connection
$db = new mysqli($servername, $userName, $password, $database, $dbport);

// Check connection
if ($db->connect_error) {
header('Content-type: text/plain');
//log error to file/db $e-getMessage()
die("END An error was encountered. Please try again later!");
}

//echo "Connected successfully (".$db->host_info.")";










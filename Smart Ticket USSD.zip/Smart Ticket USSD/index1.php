<?php

use AfricasTalking\SDK\AfricasTalking;
require 'vendor/autoload.php';

//Ensures this code runs only after a POST from AT

//remeber to return to if(!empty($_POST))
if(empty(!$_POST)) {

require_once('config.php'); // AT configuration file
require_once('dbConnector.php'); //Connects to database
require_once('AfricasTalking.php'); //AT Gateway
require_once('Service.php');
require_once('Response.php'); //File containing all resposes to user
require_once('Payments.php'); //AT Payments
require_once('SMS.php'); //AT Sms
require_once('functions.php'); // App Functions

 
ini_set('error_log', 'ATussd-app-error.log');



// Reads the variables sent via POST from AT gateway


$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"]; 
  
 
// Database Connection
global $db ;
 
// Initialize the SDK
$AT = new AfricasTalking($username, $apiKey);



//Explode the text to get the value of the latest interaction - think 1*1
$textArray = explode('*', $text);
$userResponse = trim(end($textArray));

//Set the default level of the user
$menuNumber = 0;

//Check the level of the user from the DB and retain default level if none is found for this session
$sql = "SELECT menuNumber FROM session_levels WHERE sessionId ='".$sessionId."'";
$menuNumberQuery = $db->query($sql);
if ($menuNumberQueryResult = $menuNumberQuery->fetch_assoc()) {
    $menuNumber = $menuNumberQueryResult['menuNumber'];
}


//Check if the user is registered in the database
$sql7 = "SELECT * FROM account WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1";
$userQuery = $db->query($sql7);
$userAvailable = $userQuery->fetch_assoc();

//Check if the user is available (no)->Register the user
if (!$userAvailable) {
    
	
	 $sq99 = "INSERT INTO account (phoneNumber) VALUES('".$phoneNumber."')";
     $db->query($sq99);
	
}


// Serve the Services Menu


if ($menuNumber == 0 || $menuNumber == 1) {
        switch ($userResponse) {
			
			// Main Menu
            case "":
                if ($menuNumber == 0) {
                    //9b. Graduate user to next level & Serve Main Menu
                    $sql9b = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 1 )";
                    $db->query($sql9b);
					$sql9c = "INSERT INTO `transactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                    //Serve our services menu

                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Main'];
                }
                break;
            case "0":
                if ($menuNumber == 0) {

                    $sql00 = "INSERT INTO session_levels`(`sessionId`,`phonenumber`,`menuNumber`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                    $db->query($sql00);
					$sql9c = "INSERT INTO `transactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                    //9c. Send the user Request Service Menu

                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Main'];
                }
                break;
            case "1":
                if ($menuNumber == 1) {

                    $sql01 = "UPDATE session_levels SET  menuNumber=11 WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01);
					$sql01a = "UPDATE transactions SET  ticketType = 'Movies' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
					
                   
                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Locations'];
                }
                break;
            case "2":
                if ($menuNumber == 1) {

                    $sql02 = "UPDATE session_levels SET menuNumber =20 WHERE sessionId = '".$sessionId."'";
                    $db->query($sql02);
					
					$sql01a = "UPDATE transactions SET  ticketType = 'Events' WHERE sessionId = '".$sessionId."' ";
                    $db->query($sql01a);
                  


                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    /** @noinspection PhpUndefinedVariableInspection */
                    echo $responseMsg['Locations'];
                }
                break;
			case "3":
				if ($menuNumber == 1) {

					$sql02 = "UPDATE session_levels SET menuNumber =800 WHERE sessionId = '".$sessionId."'";
					$db->query($sql02);
				


					// Print the response onto the page so that AT gateway can read it
					header('Content-type: text/plain');
					/** @noinspection PhpUndefinedVariableInspection */
					echo $responseMsg['Validation'];
				}
				break;				
            default:
                if ($menuNumber == 1) {
                    // Return user to Main Menu & Demote user's level
                    $response = "CON You have to choose a service.\n";
                    $response .= "Press 0 to go back.\n";
                    //demote
                    $sqlMenuDemote = "UPDATE session_levels SET menuNumber`=0 WHERE sessionId`='".$sessionId."'";
                    $db->query($sqlMenuDemote);

                    // Print the response onto the page so that AT gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
        }
    }else {
        switch ($menuNumber) {
			
			// Other Menu
					
            case"10":
			//Movies Tickets Location Menu
               switch ($userResponse) {
                    case "1":
                        if ($menuNumber = 10) {
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                           
						   // update Transactions Table
						   
						   $sqla = "UPDATE transactions SET re=234003 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                            header('Content-type: text/plain');
							echo $responseMsg['Lagos_Locations'];
                        }
                        break;
                    case "2":
                        if ($menuNumber = 10) {
							
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNumber =12  WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
                            
                      
                            header('Content-type: text/plain');
							echo $responseMsg['PH_Locations'];
                        }
                        break;
                    case "3":
                        if ($menuNumber = 10) {

							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNumber = 13 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
                                               
                            header('Content-type: text/plain');
							echo $responseMsg['Abuja_Locations'];
                        }
                        break;
                    case "9":
                        if ($menuNumber = 10) {

							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNumber = 1 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                            
                      
                            header('Content-type: text/plain');
							echo $responseMsg['Main'];
                        }
                        break;
                    case "0":
                        if ($menuNumber = 10) {

                            $sql = "UPDATE session_levels SET menuNumber = 0 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);

                           
                            header('Content-type: text/plain');
                            echo $$responseMsg["Exit_Msg"];;
                        }
                        break;
                    default:
                        if ($menuNumber = 10) {
                            // Return user to Main Menu & Demote user's level
                            $response = "CON Invalid Entry.\n";
                            $response .= "Enter 10 to go back.\n";
                            //demote
                            $sqlMenuDemote = "UPDATE session_levels SET menuNumber=10 WHERE sessionId`='".$sessionId."'";
                            $db->query($sqlMenuDemote);

                            // Print the response onto the page so that AT gateway can read it
                            header('Content-type: text/plain');
                            echo $response;
                            break;
                        }
                        break;
                        break;
                }
                break;
           
		    case"11":
			// Lagos Locations Menu
               switch ($userResponse) {
                    case "1":
                       if ($menuNumber = 11) {
							
							// Update transactions table
							$sql01a = "UPDATE transactions SET  state = 'Lagos' WHERE sessionId = '".$sessionId."' ";
							$db->query($sql01a);
							
							
							// Update Session
                            $sql = "UPDATE session_levels SET menuNumber =200  WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                            
                            // select all movies for Lagos Location
                            
							$sql1 = "SELECT * FROM events JOIN location ON events.location = location.locationName Where location.locationState = 'Lagos' AND events.status='Open' ORDER BY eventID  ASC LIMIT 9";
                            $queryResult= $db->query($sql1);
							
							
							if ($queryResult->num_rows > 0) {

                                $menuResult = $queryResult->fetch_all();

                               
                                $menu = serialize($menuResult);
                                
                                
                                //insert results into the ordertable
                                $sql11="INSERT INTO `orders`(`menu`, `sessionId`) VALUES ('".$menu."','".$sessionId."')";
                                $db->query($sql11);
								// output data of each row

                                $itemCount = 0;
											
								echo "CON ";
								
								
								
							foreach($menuResult as $Menu ) {
						 
							
                               echo $itemCount.'. ';
                               
                               echo $Menu['1']."\n";
									                                    
							    $itemCount++;
								} 
								
						
								
							} else {
								echo "END No available Movies. Try again Later";
							}
							
								
						
					   }
			
                        
                        break;
					case "2":
                        if ($menuNumber = 11) {
							
							// Update Session
                            $sql = "UPDATE session_levels SET menuNumber =200  WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							
							$sql1 = "SELECT * FROM `events` WHERE `eventType`='Events' and `status`= 'Open'";
                            $queryResult= $db->query($sql1);
							$result = mysqli_fetch_assoc($queryResult);
							
							$ticketPrice = $result['price'];
							$sqla = "UPDATE `transactions` SET `charge`= '".$ticketPrice."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
							
								
							$itemCount=0;				
							While($result){
								
								echo "CON ".++$itemCount.". ".$result['eventName']."\n" ;
									
														
								}
								
							if(!$result = mysqli_fetch_assoc($queryResult) ){							
                             header('Content-type: text/plain');
								echo "END No available Movies. Try again Later";}
								 			
									
							
                           
                      
                            header('Content-type: text/plain');
							//echo $responseMsg['Movies'];
                        }
                        break;	
					
                    case "9":
                        if ($menuNumber = 11) {

							// Update Session
                            $sql = "UPDATE session_levels SET menuNumber = 10 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
                            header('Content-type: text/plain');
                            echo $responseMsg[$menuName];
                        }
                        break;
                    case "0":
                        if ($menuNumber = 11) {

                            $sql = "UPDATE session_levels SET menuNumber = 0 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);

                            $menuName = "Exit_Msg";
                            /** @noinspection PhpUndefinedVariableInspection */
                            $response = $responseMsg[$menuName];
                            header('Content-type: text/plain');

                            echo $response;
                        }
                        break;
                    default:
                        if ($menuNumber = 11) {
                            // Return user to Main Menu & Demote user's level
                            $response = "CON You have to choose a service.\n";
                            $response .= "Press 10 to go back.\n";
                            //demote
                            $sqlMenuDemote = "UPDATE session_levels SET menuNumber=10 WHERE sessionId`='".$sessionId."'";
                            $db->query($sqlMenuDemote);

                            // Print the response onto the page so that AT gateway can read it
                            header('Content-type: text/plain');
                            echo $response;
                            break;
                        }
                        break;
                        break;
                }
                break;
		   
		    case"20":
			// Events Tickets Location Menu
               switch ($userResponse) {
                    case "1":
                        if ($menuNumber = 20) {

							// Update Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 21 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                                                   
                      
                            header('Content-type: text/plain');
							echo $responseMsg['Lagos_Locations'];
                        }
                        break;
                    case "2":
                        if ($menuNumber = 20) {

							// Update Session 
                            $sql = "UPDATE session_levels SET menuNumber =22  WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                            
                            header('Content-type: text/plain');
							echo $responseMsg['PH_Locations'];
                        }
                        break;
                    case "3":
                        if ($menuNumber = 20) {
							
							// Update Session 	
                            $sql = "UPDATE session_levels SET menuNumber = 23 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							             
                            header('Content-type: text/plain');
							echo $responseMsg['Abuja_Locations'];
                        }
                        break;
                    case "9":
                        if ($menuNumber = 20) {

							// Update Session 
                            $sql = "UPDATE session_levels SET menuNumber = 1 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
                                                  
                            header('Content-type: text/plain');
							echo $responseMsg['Main'];
                        }
                        break;
                    case "0":
                        if ($menuNumber = 20) {
							
							// Update Session 
                            $sql = "UPDATE session_levels SET menuNumber = 0 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);

                            header('Content-type: text/plain');
                            echo $responseMsg["Exit_Msg"];
                        }
                        break;
                    default:
                        if ($menuNumber = 20) {
                            // Return user to Main Menu & Demote user's level
                            $response = "CON You have to choose a service.\n";
                            $response .= "Press 20 to go back.\n";
                            //demote
                            $sqlMenuDemote = "UPDATE session_levels SET menuNumber=20 WHERE sessionId`='".$sessionId."'";
                            $db->query($sqlMenuDemote);

                            // Print the response onto the page so that AT gateway can read it
                            header('Content-type: text/plain');
                            echo $response;
                            break;
                        }
                        break;
                        break;
                }
                break;
				
           
				
            case"200":
			//Movies Menu
			  $selectedMenu = $userResponse;

			  if ($menuNumber = 200) {
			      
			      $sql11 = "SELECT menu FROM `orders` WHERE sessionId = '".$sessionId."'";
                $queryResult= $db->query($sql11);
                $result = mysqli_fetch_assoc($queryResult);
                $menu =	$result['menu'];
                $menu = unserialize($menu) ;

                 $requestType = $menu[$selectedMenu][1];
                 $price = $menu[$selectedMenu][3];
                 
                

				$sql = "UPDATE session_levels SET menuNumber =90  WHERE sessionId = '".$sessionId."'";
				$db->query($sql);
				
				 
				$sql1 = "UPDATE transactions SET requestType ='".$requestType."', charge ='".$price."' WHERE sessionId = '".$sessionId."'";
				$db->query($sql1);
				
				header('Content-type: text/plain');
				echo $responseMsg['Account_Number'];
			}
                  break;
		
				
			// Payments Section
			
			case"90":
				
				//Store Account Number and receive Bank Code
				$accountNumber = $userResponse;
			
						if ($menuNumber == 90) {
							
							
							
							// Save Account_Number to DB
							$sqla = "UPDATE transactions SET accountNumber= '".$accountNumber."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
							
							$sql00 = "UPDATE session_levels SET menuNumber =98  WHERE sessionId = '".$sessionId."'";
							$db->query($sql00);
							
							
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							/** @noinspection PhpUndefinedVariableInspection */
							
							echo $responseMsg['Banks1'];
						}
				
					break;
				
				
			case"98":
				switch ($userResponse) {
				// Receive Bank Code and Save Bancode, Ask for DOB
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode='234003' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
						
					case "2":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234012 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "3":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234005 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234022 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234001 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "6":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234014 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "7":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234004 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "8":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234015 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "9":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234016 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;	
						
					case "0":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 99 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
						                                           
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Banks2'];
								
                        break;
				
				}
					break;
				
			case"99":
				switch ($userResponse) {
				// Receive Bank Code and Save Bancode, Ask for Account Name
				 case "1":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234017 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Account_Name'];
								
                        break;
						
					case "2":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234009 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "3":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234010 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "4":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234020 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;	
					case "5":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234019 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "6":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234008 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "7":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode =234021 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					case "8":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 902 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Bank Code
                            $sqla = "UPDATE transactions SET bankCode=234002 WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Date_Of_Birth'];
								
                        break;
					
						
					case "0":
                        
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 98 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
						                                           
                          
							// Print the response onto the page so that AT gateway can read it
							header('Content-type: text/plain');
							echo $responseMsg['Banks1'];
								
                        break;
				
				}
					break;
		
			
			case"902":
			//Store Date of Birth, and Serve Payment Notice
			switch ($userResponse) {
				default:
				if ($menuNumber == 902) {
						
					$dateOfBirth = $userResponse;
					// Save Date_Of_Birth to DB
					$sqla = "UPDATE transactions SET dateOfBirth = '".$dateOfBirth."' WHERE sessionId = '".$sessionId."'";
					$db->query($sqla);
					
					//Update Session
					$sql00 = "UPDATE session_levels SET menuNumber =999  WHERE sessionId = '".$sessionId."'";
					$db->query($sql00);
							
							
					// Get and Notify User of the Ticket Details.
					
					 
			      $sql1b = "SELECT * FROM `transactions` WHERE sessionId = '".$sessionId."'";
                $queryResult= $db->query($sql1b);
                $result = mysqli_fetch_assoc($queryResult);
                
              

                 $requestType = $result['requestType'];
                 $price = $result['charge'];
                 
                 
                    $response = "CON You will be charged N".$price;
					$response .= " for ".$requestType.".";
					$response .= " Press 1 to continue \n";
					
					

							
					// Print the response onto the page so that AT gateway can read it
                   
                   
                    echo $response;
			
					}
			}
				break;
			
			
			case"999":
			// Processes the Payments
			 switch ($userResponse) {
                    case "1":
                        if ($menuNumber=999){
							
						// Select details from the DB
						$sql="SELECT * FROM transactions WHERE sessionId ='".$sessionId."'";
						$queryResult=$db->query($sql);
						
					
                    
                        // output data of  row
                         while ($result = mysqli_fetch_assoc($queryResult)) {
                        
						//Bank Details
							$accountNumber =$result['accountNumber'];
                            $bankCode = floatval($result['bankCode']);
                            $dateOfBirth = $result['dateOfBirth'];
							$charge =$result['charge'];
						
					
                        }
                        // Get the payments service
                        $payments   = $AT->payments();
                        
                        // Set the name of your Africa's Talking payment product
                        $productName = "Movie Ticket";
                        
                        // Set the details of the bank account to be charged
                        $bankAccount = [
                            "accountNumber" => $accountNumber,
                            "bankCode"      => $bankCode,
                            "dateOfBirth" => $dateOfBirth
                        ];
                        
                        // Set The 3-Letter ISO currency code and the checkout amount
                        $currencyCode       = "NGN";
                        $amount             = $charge;
                        
                        // Set a description of the transaction to be displayed on the
                        // clients statement
                        $narration          = "Smart Ticket Purchase";
                        
                        // Set any metadata that you would like to send along with this request.
                        // This metadata will be included when we send back the final payment notification
                        $metadata = [
                            "agentId"   => "654",
                            "productId" => "4153"
                        ];
                        
                        // That's it, hit send and we'll take care of the rest
                        try {
                            $checkoutResult = $payments->bankCheckoutCharge([
                                "productName"  => $productName,
                                "bankAccount"  => $bankAccount,
                                "currencyCode" => $currencyCode,
                                "amount"       => $amount,
                                "narration"    => $narration,
                                "metadata"     => $metadata
                            ]);
                        
                            // Now you must validate the checkout by sending the transactionId generated from
                            // this request and an OTP you collect from the user. See Bank Checkout Validate
                               if ($checkoutResult['status'] == "success"){
                                                    
                                   $t_ID = TicketId();    
                                   $ticketId = $checkoutResult['transactionId'];
                                   
                                   //Save Ticket Details to DB
                                   
                                   $sql01a = "UPDATE transactions SET  ticketId = '".$t_ID."' WHERE sessionId = '".$sessionId."' ";
                                    $db->query($sql01a);
                                   
                                     // Get the SMS service
                                            $sms        = $AT->sms();
                                            
                                            // Set the numbers you want to send to in international format
                                            $recipients = $phoneNumber;
                                            
                                        
                                            // Set your message
                                            $message     = "Your Ticket ID is ".$t_ID." Please Validate your purchase with the OTP Sent by your Bank to Complete Purchase.";
                                            
                                            
                                            // Set your shortCode or senderId
                                            $from       = "2305";
                                            
                                            try {
                                                // Thats it, hit send and we'll take care of the rest
                                                $result = $sms->send([
                                                    'to'      => $recipients,
                                                    'message' => $message,
                                                    'from'    => $from
                                                ]);
                                            
                                               
                                               if ($result['status'] == "success"){
                                                    
                                                    echo "END Success!\nPlease Validate your Ticket Purchase with the OTP sent by your Bank!";
                                                   
                                               }
                                               
                                            } catch (Exception $e) {
                                                echo "END ";
                                                echo "Error: ".$e->getMessage();
                                                
                                            }
                                                        
                                }else{
                                    
                                    print_r($result);
                                    echo $result ;
                                }
                        } catch(Exception $e) {
                            echo "Error: ".$e->getMessage();
                        }

                    
                    
                    
                        }
                           
                           break;
					default:
                      Echo "END Thank You!";
                        break;	
			
               
			   break;
          
			 }
				
				Break;
				
			case"800":
			// Validate Service Request Via OTP
			
			if ($menuNumberr==800){
				// Get the payments service
				$payments   = $AT->payments();

				// Set the transactionId you got from the
				// bank checkout charge request
				$sql1a="SELECT * FROM `transactions` WHERE `phoneNumber`= AND `comment`= 'pending' LIMIT 1";
				$queryResult= $db->query($sql1a);
				$result1 = mysqli_fetch_assoc($queryResult);
				
				$transactionId = $result1['ticketId'];
				
				

				// Set the OTP given to you by the user you're charging
				$otp           = $userResponse;

				// That's it, hit send and we'll take care of the rest
				try {
					$result = $payments->bankCheckoutValidate([
						"transactionId" => $transactionId,
						"otp"           => $otp
					]);
					echo "END Success".$result;
					print_r($result);
				} catch (Exception $e) {
					echo "Error: ".$e->getMessage();
				}
				
			}
			
			
			Break;
		

} 



}
}
?>
<?php
$responseMsg = array(

"Main" => "CON Welcome to Smart Tickets\n1. Movie Tickets\n2. Events Tickets\n3. Validate OTP\n4. Anike Natural",

"Error_On_Main" => "CON Wrong Input!\n1. Movie Tickets\n2. Events Tickets\n3. Validate OTP\n4. Anike Natural",

"ABS_MENU_1" => "CON 1. Small ABS w/ Carrots (N5,118.75)\n2. Small ABS w/ Turmeric (N4,331.25)\n3. Small ABS w/ Cucumber (N4,331.25)\n4. Small African Black Soap (N4,331.25) \n0. Next",

"ABS_MENU_2" => "CON 5. Big ABS w/ Carrots (N8,662.5)\n6. Big ABS w/ Turmeric (N8,662.5)\n7. Big ABS w/ Cucumber (N8,662.5)\n8. ABS w/ Kojic Acid & Mulberry (N7,875)",


"Locations" => "CON Please select your Location: \n1.Lagos\n2.PH\n3.Abuja\n4.Delta\n9.Back",

"Lagos_Locations" => "CON Which part of Lagos: \n1.Mainland \n2.Island \n9.Back",

"PH_Locations" => "END Service coming soon.\nThank You",

"Abuja_Locations" => "END Service Coming soon.\nThank You.!",

"Mainland_Events" => "END Service Coming soon.\nThank You.!",

"Island_Events" => "CON \n1.Film House Lekki \n2.Genesis Deluxe Lekki \n3.Silverbird VI \n9.Back",

"FH_Films" => "END Service Coming soon.\nThank You.!",

 "Account_Number" =>"CON Enter Bank Your Account Number",
 
 "dateOfBirth" =>"CON Enter Date of Birth(DDMMYYYY)",
 
 
 "Validation" =>"CON Enter OTP",
 "Banks" =>"CON Select Your Bank:\n1 Access \n2 FCMB \n3 Sterling \n4 Zenith\n5 Providus ",
 
 "Banks1" =>"CON Select Your Bank:\n1 ACCESS\n2 AFRIBANK\n3 ECOBANK\n4 FBN\n5 FCMB\n6 FIDELITY\n7 GTBANK\n8 HERITAGE \n9 KEYSTONE\n0 Next",
 
 "Banks2" =>"CON Select Your Bank:\n1 SKYE\n2 STANBIC\n3 STERLING\n4 UBA\n5 UNION\n6 UNITY\n7 WEMA\n8 ZENITH\n0 Back",
 
 
 "Account_Name" =>"CON Enter your Bank Account Name:",
 
"Movies" => "CON 1.Deadpool(Thurs 11am,3pm, 6pm)N1500 \n2.Ocean8 (Sat 11am, 3pm,7pm)N1500  \n9.Main \n0.Exit",

"Payment_Notice" => "CON Your will be charged N1500 + N100 Service Fee. \n Total: N1600 \n1. Proceed \n2 . Opt- Out",

"No_Service" => "END Service Coming soon.\nThank You.!",

"No_Customer" => "END Sorry, Customer doesn't exist. Please Register.",

"Exit_Msg" => "END Exit Program!",

"Error" => "END An Error Occurred. Please Try Again! \nThank You!",

"Registration_Success" => "END You have Successfully Registered for our  Service. Please dial *566# to book a ticket."
);





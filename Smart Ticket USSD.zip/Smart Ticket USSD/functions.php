 
<?php


Function TicketId(){
    
   global $db, $sessionId;
   

	// Get the Transaction ID

 				$sql = "SELECT * FROM `transactions` WHERE sessionId = '".$sessionId."'";
                $queryResult= $db->query($sql);
                $transactionID = $queryResult->fetch_assoc();
                
                if ($transactionID){
                
                $t_ID = $transactionID['transactionID'];
                 
               
			
       // Create Ticket ID
		$ticket_id='ST'.date("ym").$t_ID;
		
		

                return $ticket_id;
                 
                 }else {
                     
                     $ticket_id='ST'.date("ym").'ABC';
                     
                     return $ticket_id;
                 }

}
                 

                 ?>